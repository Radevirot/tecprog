package tp2ej2y4;

public interface Imprimible {

	public String imprimir();
	
}
