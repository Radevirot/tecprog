package tp2ej1;

public class IVA {
  private String desc;

public IVA(String desc) {
	super();
	this.desc = desc;
}
  
  
  
}

