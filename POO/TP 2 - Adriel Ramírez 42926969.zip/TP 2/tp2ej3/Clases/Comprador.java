package tp2ej3;

public class Comprador {

  private String dni;
  public Persona persona;
  
  
public Comprador(String dni, Persona persona) {
	super();
	this.dni = dni;
	this.persona = persona;
}
  
  
  
  
}