package tp2ej3;

public class Due�o {

  private String telefono;
  private Persona persona;
  
public Due�o(String telefono, Persona persona) {
	super();
	this.telefono = telefono;
	this.persona = persona;
}
  
}