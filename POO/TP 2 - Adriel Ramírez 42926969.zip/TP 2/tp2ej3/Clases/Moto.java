package tp2ej3;

public class Moto extends Vehiculo {

	public Moto(String marca, int modelo, String patente, float precio, int kilometraje, Due�o due�o) {
		super(marca, modelo, patente, precio, kilometraje, due�o);
		// TODO Auto-generated constructor stub
	}

}