package tp2ej3;

public class Camioneta extends Vehiculo {

	public Camioneta(String marca, int modelo, String patente, float precio, int kilometraje, Due�o due�o) {
		super(marca, modelo, patente, precio, kilometraje, due�o);
		// TODO Auto-generated constructor stub
	}

}