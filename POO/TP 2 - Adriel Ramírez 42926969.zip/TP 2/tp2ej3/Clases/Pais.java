package tp2ej3;

public class Pais {

  private String pais;
  public static final String NACIONAL = "Argentina";
  
  
public Pais(String pais) {
	super();
	this.pais = pais;
}
    
  String getPais() {  return this.pais;  }
  
  
}