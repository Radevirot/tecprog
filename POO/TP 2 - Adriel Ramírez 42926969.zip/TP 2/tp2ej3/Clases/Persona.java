package tp2ej3;

public class Persona {

  private String apellido;
  private String nombre;
  
public Persona(String apellido, String nombre) {
	super();
	this.apellido = apellido;
	this.nombre = nombre;
}
  
  

    
}