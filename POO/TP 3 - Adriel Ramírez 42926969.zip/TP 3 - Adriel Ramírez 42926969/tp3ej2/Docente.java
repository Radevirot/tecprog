package tp3ej2;

public class Docente {

	private Persona persona;

	public Docente(Persona persona) {
		super();
		this.persona = persona;
	}
	
	
  
}