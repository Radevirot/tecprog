package tp3ej2;

public class TipoExamen {

  private String tipo;

public TipoExamen(String tipo) {
	super();
	this.tipo = tipo;
}
  
}