package tp3ej4;

public class Titular {
	
	

  public Titular(String nombre, String apellido, String cuil) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.cuil = cuil;
	}
private String nombre;
  private String apellido;
  private String cuil;

  
}