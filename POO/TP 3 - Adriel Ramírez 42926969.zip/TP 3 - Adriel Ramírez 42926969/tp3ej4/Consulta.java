package tp3ej4;

import java.util.Calendar;

public class Consulta extends Transaccion {

	public Consulta(Calendar fecha) {
		super(fecha);
	}

	@Override
	public Float obtenerMontoEnPesos() {
		// TODO Auto-generated method stub
		return 0f;
	}
	
	
	
}